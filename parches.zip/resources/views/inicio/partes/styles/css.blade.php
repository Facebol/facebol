<link rel="shortcut icon" href="assets/img/favicon30f4.png?v=3">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="{{asset('assets/css/preload.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/plugins.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/style.light-blue-500.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/width-boxed.min.css')}}" id="ms-boxed" disabled="">
<script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">