<script src="{{asset('assets/js/plugins.min.js')}}"></script>
<script src="{{asset('assets/js/app.min.js')}}"></script>

<script src="{{asset('assets/js/index.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
