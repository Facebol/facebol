<header class="ms-header ms-header-primary">
    <!--ms-header-primary-->
    <div class="container container-full">
      <div class="ms-title">
        <a href="{{route('inicio')}}">
          <img src="{{asset('imagen/'.$institucion->imagen)}}" alt="" width="200px" height="80px"> 
          <!-- <span class="ms-logo animated zoomInDown animation-delay-5">F</span>
          <h1 class="animated fadeInRight animation-delay-6">ace
            <span>Bol</span>
          </h1>-->
        </a>
      </div> 
      <div class="header-right">
        <div class="share-menu">
          <ul class="share-menu-list">
            <li class="animated fadeInRight animation-delay-3">
              <a href="javascript:void(0)" class="btn-circle btn-google">
                <i class="zmdi zmdi-google"></i>
              </a>
            </li>
            <li class="animated fadeInRight animation-delay-2">
              <a href="javascript:void(0)" class="btn-circle btn-facebook">
              </a>
              <i class="zmdi zmdi-facebook"></i>
            </li>
            <li class="animated fadeInRight animation-delay-1">
              <a href="javascript:void(0)" class="btn-circle btn-twitter">
                <i class="zmdi zmdi-twitter"></i>
              </a>
            </li>
          </ul>
          <a href="javascript:void(0)" class="btn-circle btn-circle-primary animated zoomInDown animation-delay-7">
            <i class="zmdi zmdi-share"></i>
          </a>
        </div>
        <a href="javascript:void(0)" class="btn-circle btn-circle-primary no-focus animated zoomInDown animation-delay-8" data-toggle="modal" data-target="#ms-account-modal">
          <i class="zmdi zmdi-account"></i>
        </a>
        <a href="javascript:void(0)" class="btn-ms-menu btn-circle btn-circle-primary ms-toggle-left animated zoomInDown animation-delay-10">
          <i class="zmdi zmdi-menu"></i>
        </a>
      </div>
    </div>
  </header>